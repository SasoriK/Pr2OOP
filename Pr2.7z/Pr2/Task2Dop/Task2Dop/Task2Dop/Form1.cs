﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task2Dop
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Метод Евклида для двух значений
        /// </summary>
        /// <param name="a">Челое число</param>
        /// <param name="b">Целое число</param>
        /// <returns>Возвращает НОД двух целых чисел</returns>
        int NOD(int a, int b)
        {
            if (a == 0) return b;
            while (b != 0)
            {
                if (a > b)
                {
                    a -= b;
                }
                else
                {
                    b -= a;
                }
            }
            return a;
        }
        /// <summary>
        /// Перегруженный метод Евклида для неопределенного количества значений
        /// </summary>
        /// <param name="rightData">Массив чисел</param>
        /// <returns>Возвращает НОД массива целых чисел</returns>
        int NOD(params int[] rightData)//метод Евклида
        {
            int first = NOD(rightData[0], rightData[1]);
            if (rightData.Length > 2)
            {
                for (int n = 2; n < rightData.Length; n++)
                {
                    first = NOD(first, rightData[n]);
                }
                return first;
            }
            else return first;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] data = textBox1.Text.Split(' ');
            int[] rightData = Array.ConvertAll(data, int.Parse);
            label1.Text ="Результат: " + NOD(rightData).ToString();
        }
    }
}
