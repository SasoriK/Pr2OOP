﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task1
{
    public partial class Form1 : Form
    {
        void Euclid()
        {
            bool parseA = int.TryParse(textBoxA.Text, out var a);
            if (parseA == true)
            {
                //Получаем второе значение
                bool parseB = int.TryParse(textBoxB.Text, out var b);
                if (parseB == true)
                {
                    //Выводим результат
                    lbEuclidResult.Text = "НОД = " + NOD(a, b).ToString() + " (метод Евклида)";
                }
                else { MessageBox.Show("Некорректный ввод"); return; }
            }
            else { MessageBox.Show("Некорректный ввод"); return; }
        }
/// <summary>
/// Метод, вычисляющий наибольший общий делитель методом Евклида.
/// Принимает на вход числовые параметры a и b.
/// </summary>
/// <param name="a">Число, полученное из textBoxA</param>
/// <param name="b">Число, полученное из textBoxB</param>
/// <returns>Наибольший общий делитель</returns>
        public static int NOD(int a, int b)//метод Евклида
        {
            if (a == 0) return b;
            while (b != 0)
            {
                if (a > b)
                {
                    a -= b;
                }
                else
                {
                    b -= a;
                }
            }
            return a;
        }
        /// <summary>
        /// Перегруженная версия метода NOD для трех переменных
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <returns></returns>
        public static int NOD(int a, int b, int c)
        {
            int d = NOD(a, b);
            int e = NOD(d, c);
            return e;
        }
        /// <summary>
        /// Перегруженная версия метода NOD для четырех переменных
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <param name="d"></param>
        /// <returns></returns>
        public static int NOD(int a, int b, int c, int d)
        {
            int three = NOD(a, b, c);
            int e = NOD(three, d);
            return e;
        }
        /// <summary>
        /// Перегруженная версия метода NOD для пяти переменных
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <param name="d"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        public static int NOD(int a, int b, int c, int d, int e)
        {
            int four = NOD(a, b, c, d);
            int r = NOD(four, e);
            return r;
        }
        public Form1()
        {
            InitializeComponent();
        }

        //Если нажата вторая кнопка
        private void btCalcEuclid_Click(object sender, EventArgs e)
        {
            Euclid();
        }
        //Если нажата третья кнопка
        private void bt3Int_Click(object sender, EventArgs e)
        {
            bool parseA = int.TryParse(textBoxA.Text, out var a);
            if (parseA == true)
            {
                bool parseB = int.TryParse(textBoxB.Text, out var b);
                if (parseB == true)
                {
                    bool parseC = int.TryParse(textBoxC.Text, out var c);
                    if (parseC == true)
                    {
                        lbEuclidResult.Text = "НОД = " + NOD(a, b, c).ToString() + " (метод Евклида)";
                    }
                    else { MessageBox.Show("Некорректный ввод"); return; }
                }
                else { MessageBox.Show("Некорректный ввод"); return; }
            }
            else { MessageBox.Show("Некорректный ввод"); return; }
        }
        //Если нажата четвертая кнопка
        private void bt4Int_Click(object sender, EventArgs e)
        {
            bool parseA = int.TryParse(textBoxA.Text, out var a);
            if (parseA == true)
            {
                bool parseB = int.TryParse(textBoxB.Text, out var b);
                if (parseB == true)
                {
                    bool parseC = int.TryParse(textBoxC.Text, out var c);
                    if (parseC == true)
                    {
                        bool parseD = int.TryParse(textBoxD.Text, out var d);
                        if (parseD == true)
                        {
                            lbEuclidResult.Text = "НОД = " + NOD(a, b, c, d).ToString() + " (метод Евклида)";
                        }
                        else { MessageBox.Show("Некорректный ввод"); return; }
                    }
                    else { MessageBox.Show("Некорректный ввод"); return; }
                }
                else { MessageBox.Show("Некорректный ввод"); return; }
            }
            else { MessageBox.Show("Некорректный ввод"); return; }
        }
        //Если нажата пятая кнопка
        private void bt5Int_Click(object sender, EventArgs e)
        {
            bool parseA = int.TryParse(textBoxA.Text, out var a);
            if (parseA == true)
            {
                bool parseB = int.TryParse(textBoxB.Text, out var b);
                if (parseB == true)
                {
                    bool parseC = int.TryParse(textBoxC.Text, out var c);
                    if (parseC == true)
                    {
                        bool parseD = int.TryParse(textBoxD.Text, out var d);
                        if (parseD == true)
                        {
                            bool parseE = int.TryParse(textBoxE.Text, out var e5);
                            if (parseE == true)
                            {
                                lbEuclidResult.Text = "НОД = " + NOD(a, b, c, d, e5).ToString() + " (метод Евклида)";
                            }
                            else { MessageBox.Show("Некорректный ввод"); return; }
                        }
                        else { MessageBox.Show("Некорректный ввод"); return; }
                    }
                    else { MessageBox.Show("Некорректный ввод"); return; }
                }
                else { MessageBox.Show("Некорректный ввод"); return; }
            }
            else { MessageBox.Show("Некорректный ввод"); return; }
        }
    }
}
