﻿
namespace Task1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxA = new System.Windows.Forms.TextBox();
            this.textBoxB = new System.Windows.Forms.TextBox();
            this.btCalcEuclid = new System.Windows.Forms.Button();
            this.lbEuclidResult = new System.Windows.Forms.Label();
            this.textBoxC = new System.Windows.Forms.TextBox();
            this.textBoxD = new System.Windows.Forms.TextBox();
            this.textBoxE = new System.Windows.Forms.TextBox();
            this.bt3Int = new System.Windows.Forms.Button();
            this.bt4Int = new System.Windows.Forms.Button();
            this.bt5Int = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxA
            // 
            this.textBoxA.Location = new System.Drawing.Point(66, 40);
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.Size = new System.Drawing.Size(100, 20);
            this.textBoxA.TabIndex = 0;
            // 
            // textBoxB
            // 
            this.textBoxB.Location = new System.Drawing.Point(66, 84);
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.Size = new System.Drawing.Size(100, 20);
            this.textBoxB.TabIndex = 1;
            // 
            // btCalcEuclid
            // 
            this.btCalcEuclid.Location = new System.Drawing.Point(215, 84);
            this.btCalcEuclid.Name = "btCalcEuclid";
            this.btCalcEuclid.Size = new System.Drawing.Size(75, 23);
            this.btCalcEuclid.TabIndex = 2;
            this.btCalcEuclid.Text = "2 числа";
            this.btCalcEuclid.UseVisualStyleBackColor = true;
            this.btCalcEuclid.Click += new System.EventHandler(this.btCalcEuclid_Click);
            // 
            // lbEuclidResult
            // 
            this.lbEuclidResult.AutoSize = true;
            this.lbEuclidResult.Location = new System.Drawing.Point(63, 292);
            this.lbEuclidResult.Name = "lbEuclidResult";
            this.lbEuclidResult.Size = new System.Drawing.Size(35, 13);
            this.lbEuclidResult.TabIndex = 3;
            this.lbEuclidResult.Text = "label1";
            // 
            // textBoxC
            // 
            this.textBoxC.Location = new System.Drawing.Point(66, 131);
            this.textBoxC.Name = "textBoxC";
            this.textBoxC.Size = new System.Drawing.Size(100, 20);
            this.textBoxC.TabIndex = 4;
            // 
            // textBoxD
            // 
            this.textBoxD.Location = new System.Drawing.Point(66, 183);
            this.textBoxD.Name = "textBoxD";
            this.textBoxD.Size = new System.Drawing.Size(100, 20);
            this.textBoxD.TabIndex = 5;
            // 
            // textBoxE
            // 
            this.textBoxE.Location = new System.Drawing.Point(66, 227);
            this.textBoxE.Name = "textBoxE";
            this.textBoxE.Size = new System.Drawing.Size(100, 20);
            this.textBoxE.TabIndex = 6;
            // 
            // bt3Int
            // 
            this.bt3Int.Location = new System.Drawing.Point(215, 131);
            this.bt3Int.Name = "bt3Int";
            this.bt3Int.Size = new System.Drawing.Size(75, 23);
            this.bt3Int.TabIndex = 7;
            this.bt3Int.Text = "3 числа";
            this.bt3Int.UseVisualStyleBackColor = true;
            this.bt3Int.Click += new System.EventHandler(this.bt3Int_Click);
            // 
            // bt4Int
            // 
            this.bt4Int.Location = new System.Drawing.Point(215, 183);
            this.bt4Int.Name = "bt4Int";
            this.bt4Int.Size = new System.Drawing.Size(75, 23);
            this.bt4Int.TabIndex = 8;
            this.bt4Int.Text = "4 числа";
            this.bt4Int.UseVisualStyleBackColor = true;
            this.bt4Int.Click += new System.EventHandler(this.bt4Int_Click);
            // 
            // bt5Int
            // 
            this.bt5Int.Location = new System.Drawing.Point(215, 227);
            this.bt5Int.Name = "bt5Int";
            this.bt5Int.Size = new System.Drawing.Size(75, 23);
            this.bt5Int.TabIndex = 9;
            this.bt5Int.Text = "5 чисел";
            this.bt5Int.UseVisualStyleBackColor = true;
            this.bt5Int.Click += new System.EventHandler(this.bt5Int_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bt5Int);
            this.Controls.Add(this.bt4Int);
            this.Controls.Add(this.bt3Int);
            this.Controls.Add(this.textBoxE);
            this.Controls.Add(this.textBoxD);
            this.Controls.Add(this.textBoxC);
            this.Controls.Add(this.lbEuclidResult);
            this.Controls.Add(this.btCalcEuclid);
            this.Controls.Add(this.textBoxB);
            this.Controls.Add(this.textBoxA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxA;
        private System.Windows.Forms.TextBox textBoxB;
        private System.Windows.Forms.Button btCalcEuclid;
        private System.Windows.Forms.Label lbEuclidResult;
        private System.Windows.Forms.TextBox textBoxC;
        private System.Windows.Forms.TextBox textBoxD;
        private System.Windows.Forms.TextBox textBoxE;
        private System.Windows.Forms.Button bt3Int;
        private System.Windows.Forms.Button bt4Int;
        private System.Windows.Forms.Button bt5Int;
    }
}

