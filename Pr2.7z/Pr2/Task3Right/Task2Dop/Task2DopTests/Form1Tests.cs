﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Task2Dop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2Dop.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void FindGCDSteinTest()
        {
            int a = 298467352;
            int b = 569484;
            long time;
            int expected = 4;
            Assert.AreEqual(expected, Form1.FindGCDStein(a, b, out time));
        }

        [TestMethod()]
        public void NODTest()
        {
            int a = 298467352;
            int b = 569484;
            long time;
            int expected = 4;
            Assert.AreEqual(expected, Form1.NOD(a, b, out time));
        }
    }
}